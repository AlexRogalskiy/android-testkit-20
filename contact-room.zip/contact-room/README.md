# contact-room
A simple android project demonstrating use of Room with all CRUD operations.

### [Click here to read the tutorial](http://thetechnocafe.com/how-to-use-room-in-android-all-you-need-to-know-to-get-started/)

!["Image"](http://thetechnocafe.com/wp-content/uploads/2018/02/using-room-in-android.jpg)
